#include <iostream>
#include <cstdbool>
//#include "Card.h"
#include "Deck.h"

vector<Card> initPlayer(Deck d);
vector<Card> initDealer(Deck d);

bool hasAce (vector<Card> hand);
